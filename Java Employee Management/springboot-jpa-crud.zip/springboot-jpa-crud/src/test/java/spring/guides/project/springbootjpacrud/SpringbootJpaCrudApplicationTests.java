package spring.guides.project.springbootjpacrud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootJpaCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
